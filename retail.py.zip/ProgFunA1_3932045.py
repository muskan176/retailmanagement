                                        ##** RETAIL MANAGEMENT SYSTEM **##
customers = ['Muskan','Astle','Ajinkya','Saumya','Pranav','Sneha']
product = ['Laptop','Watch','Speaker','Charger','Bottle']
product_price = [120, 50, 60, 24, 25]
membership_list = ['Muskan','Astle','Ajinkya','Saumya','Pranav']
products = dict(zip(product,product_price))


####################################################################################################

order_list = []
prod_list = []
customer_expenditures = {}
order_id = dict()
order_no = 1

######################################################################################################  

def placeorder():
    global order_no
    global input_customer
    #CUSTOMER NAME
    input_customer = input("Enter the name of the customer: \n")
    if input_customer not in customers:
        customers.append(input_customer)

    # THE NAME OF THE PRODUCT IS CHOSEN
    def products_fun():
        global input_product
        global price
        global total

        productlist()
        input_product = input("Enter the name of the product [A valid product]: \n")
       
        #VALIDATING PRODUCT
        while input_product not in product:
            print("Sorry,this does not exist in our product list")  
            input_product = input("Enter the name of the product name again![A valid product]: \n")
        
        if input_product in products:
            price = int(products[input_product])
        #VALIDATING PRICE
            if price == 0:
                input_product = input('Enter the product again as the price for this is $0')

        # THE QUANTITY OF THE PRODUCT IS ASKED
        while True:
            try:
                global input_quantity
                input_quantity = int(input("Enter the quantity of the product [enter a positive integer]\n"))  
        #VALIDATING QUANTITY 
            except ValueError:  
                print("Please enter a valid positive integer quantity")
            if input_quantity<=0:
                print('Invalid')
                continue
            else:
                break
        total = price * input_quantity
         
    products_fun()    
   
    order_list = []
    while True:
#LIST IS MADE TO INPUT ALL THE PRODUCT DETAILS 
        prod_list = [input_product,input_quantity,price,total,input_customer]
        order_list.append(prod_list) 

        want_prod = input("Do you want to add more products?(y/n)")

        if want_prod == 'y' or want_prod == 'Y':
            products_fun()
              
        if want_prod == 'n' or want_prod == 'N':
            if input_customer in order_id:
                order_id[input_customer].append(order_list)
            else:
                order_id[input_customer] = [1, order_list]
            order_id[input_customer][0] = order_no
            order_no+=1
            break  
# BILL IS CALCULATED WITH DISCOUNT OF MEMBERS
    def discount():
            i=0
            j=0
            print('-----------------------------------------------')
            while i<len(order_list):
                while j<len(prod_list):
                    if order_list[i][j+4] == input_customer:
                        print('{} purchases {} x {}.'.format(input_customer,order_list[i][j+1],order_list[i][j]))
                        print('Unit price:   \t\t\t {} AUD'.format(int(order_list[i][j+2])))
                    i=i+1
                    break    
            print('{} gets a discount of 5.0 %'.format(input_customer)) 
            d = 0
            i = 0
            j = 0
            global sum
            while i<len(order_list):
                while j<len(prod_list):
                    if order_list[i][j+4] == input_customer:
                        d = d + order_list[i][j+3]
                    i=i+1
                    break 
            sum = 0.95 * d
            print('Total price: \t\t\t{} AUD'.format(sum))
        
            print('-----------------------------------------------\n\n')

#BILL IS CALCULATED FOR NON-MEMBERS           
    def original():
            
            i = 0
            j = 0
            
            print('-----------------------------------------------')
            while i<len(order_list):
                while j<len(prod_list):
                    if order_list[i][j+4] == input_customer:
                        print('{} purchases {} x {}.'.format(input_customer,order_list[i][j+1],order_list[i][j]))
                        print('Unit price:   \t\t\t {} AUD'.format(int(order_list[i][j+2])))
                    i=i+1
                    break    
            
            print('{} gets a discount of 0.0 %'.format(input_customer)) 
            
            global sum
            sum = 0
            i = 0
            j = 0
            
            while i<len(order_list):
                while j<len(prod_list):
                    if order_list[i][j+4] == input_customer:
                        sum = sum + order_list[i][j+3]
                    i=i+1
                    break 
            print('Total price: \t\t\t{} AUD'.format(sum))
           
            print('-----------------------------------------------\n\n')

#TO ASK IF THEY ARE THE MEMBER OR NOT
    def membership():
        if input_customer in membership_list:
            print("You are a member and you will get 5% discount!")
            discount()        
        else:    
            print("You are not a member and cannot get discount!")
            while True:
                want_membership = input("Do you want to take a membership(y/n)?")

                if want_membership == 'Y' or want_membership == 'y':
                    membership_list.append(input_customer)
                    print(membership_list)
                    discount()
                    break
                if want_membership == 'N' or want_membership == 'n':
                    print("You don't get a discount!")
                    original()
                    break
                else:
                    print('Invalid input')
    membership()

 ######################################################################################################  
#FUNCTION TO UPDATE THE PRODUCT LIST
def update():
        
        product = input('\nEnter the products to be added/updated: ')
        product_list = product.split(',')
        prices = input('\nEnter the prices of the products to be added/updated: ')
        prices_list = prices.split(',')
        ProductPrices_dictionary = dict(zip(product_list,prices_list))
        print(ProductPrices_dictionary)
        products.update(ProductPrices_dictionary)
        print(products)
        for key,value in ProductPrices_dictionary.items():
            if key not in products:
                products.append(key)
        print(products)
        print('\nProduct list has been updated.')
                
######################################################################################################           
#FUNCTION TO DISPLAY ALL THE LIST OF MEMBERSHIP OF THE MEMBERS AVAILABLE
def memberlist():
    print('+++++++++++++++++++++++++++')
    print("      LIST OF MEMBERS     ")
    for member in membership_list:
        print(member)
    print('+++++++++++++++++++++++++++')
######################################################################################################  
#FUNCTION TO DISPLAY ALL THE LIST OF CUSTOMER AVAILABLE
def customerlist():
    print('+++++++++++++++++++++++++++')
    print("      LIST OF CUSTOMERS     ")
    for customer in customers:
        print(customer)
    print('+++++++++++++++++++++++++++')   
######################################################################################################  
#FUNCTION TO DISPLAY ALL THE LIST OF PRODUCTS AVAILABLE
def productlist():
    print('++++++++++++++++++++++++++++++')
    print("      LIST OF PRODUCTS     ")
    for i in product:
        print(i) 
    print('++++++++++++++++++++++++++++++')  
######################################################################################################      

def valuable_cust():    

    cust_list = []
    price_list = []
    cus_price = []
    total_list = []
        
    for key,value in order_id.items():
        if type(value) == list:
            price_list.append(value)
        if type(key) != list:
            cust_list.append(key)
    for i in price_list:
        for j in i[1]:
            if j[-1] in cust_list:
                cus_price = [j[-1],j[3]]
                total_list.append(cus_price)
    
    C = dict()
    for i in range(len(cust_list)):
        s = 0
        for j in range(len(total_list)):
            if (total_list[j][0] == cust_list[i]):
                s += total_list[j][1]
            C.update({cust_list[i]:s})
    print(C)

    max_key = max(C, key = C.get)

    print('The most valuable customer for us is: '+ max_key)

def cust_history():

    x = input('Please enter a customer name for checking order history: \n')

    if x != input_customer:
        print('Please enter a valid customer!')
        x = input('Please enter a customer name again for checking order history: \n')

    cust_list = []
    cust_list = order_id.get(x)
    
    prd_list = set()
    for i in cust_list:
        if type(i) == list:
            for j in i:
                prd_list.add(j[0])
    qty_list = list()
    for i in cust_list:
        if type(i) == list:
            for p in prd_list:
                for j in i:
                    if p in j:
                        qty_list.append(j[1]) 
    

    string = '           \t'
    for i in prd_list:
        string = string + i + '\t'
    print(string)

    number_of_orders = 0
    for i in cust_list:
        if type(i) == list:
            string = 'Purchase ' + str(number_of_orders+1) + '\t '
            for prod in prd_list:
                for j in i:
                    if prod in j:
                        string = string + str(j[1]) + '   '
                    else:
                        string = string + '   '
        else:
            continue
        print(string)
        number_of_orders += 1
    




def menu():
    while True:
        print("\n\nWelcome to the RMIT retail management system!\n")
        print("########################################")
        print("You can choose the following options:")
        print(' 1: Place an order\n 2: Add/update products and prices\n 3: Display existing customers\n 4: Display existing with membership\n 5: Display existing products\n 6: Display the most valuable customer\n 7: Display a customer order history\n 0: Exit the program')
        print("########################################")
        print("\nChoose one option: ")
        input_choice = input("\nEnter a choice: ")
        if input_choice == '1':
            placeorder()   
        elif input_choice == '2':
            update()
        elif input_choice == '3':
            customerlist()  
        elif input_choice == '4':
            memberlist()
        elif input_choice == '5':
            productlist()
        elif input_choice == '6':
            valuable_cust()
        elif input_choice == '7':
            cust_history()
        elif input_choice == '0':
            break
        else:
            print('Invalid Choice')

menu()    


